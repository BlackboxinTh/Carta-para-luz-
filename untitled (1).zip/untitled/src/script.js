const text = "Mi querida Luz, han pasado 2 años desde que decidimos caminar juntos. Cada momento contigo es un hermoso capítulo de nuestra historia. \nEres mi felicidad y mi todo. Hoy quiero preguntarte algo muy especial...";
let i = 0;

function escribirTexto() {
    if (i < text.length) {
        document.getElementById("message").innerHTML += text.charAt(i);
        i++;
        setTimeout(escribirTexto, 50);
    }
}

function mostrarInvitacion() {
    document.getElementById("invitation").classList.remove("hidden");
}

function aceptarInvitacion() {
    let button = document.getElementById("accept-btn");
    button.innerHTML = "💖 ¡Te amo! 💖";
    button.style.background = "#ff4081";
    button.style.transform = "scale(1.2)";
    lanzarConfeti();
}

/* Efecto de confeti */
const canvas = document.getElementById("confetti");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const confetti = [];

function lanzarConfeti() {
    for (let i = 0; i < 100; i++) {
        confetti.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height - canvas.height,
            r: Math.random() * 10 + 2,
            d: Math.random() * 10 + 2
        });
    }
}

function dibujarConfeti() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (let i = 0; i < confetti.length; i++) {
        let c = confetti[i];
        ctx.beginPath();
        ctx.arc(c.x, c.y, c.r, 0, Math.PI * 2, false);
        ctx.fillStyle = "rgba(255, 0, 0, 0.8)";
        ctx.fill();
        c.y += c.d;
    }
}

setInterval(dibujarConfeti, 30);

window.onload = escribirTexto;
